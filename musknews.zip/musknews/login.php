<?php
require_once 'config.php';

$link = mysqli_connect($host, $user, $password, $database)
or die("Ошибка " . mysqli_error($link));

if ($_POST['email'] != '' && $_POST['password'] != '' ) {
    $login = trim($_POST['email']);
    $pass = trim($_POST['password']);

    $result = mysqli_query($link, "SELECT * FROM `users` WHERE `email` = '$login'");
    $res2 = $result->fetch_assoc();
    if ($login === $res2['email'] && $pass === $res2['password']) {
        $_SESSION['id'] = $res2['id'];
        $_SESSION['name'] = $res2['name'];
        $_SESSION['is_admin'] = $res2['is_admin'];
    }else {
        $mssg = 'Введите корректные данные';
    }
    header("Location: index.php");
}

include_once('view/header.php');
?>
    <div class="flex-center position-ref full-height">
        <div class="container">
            <?if (isset($_SESSION['id'])):?>
                <?
                    $mssg = 'Вы уже авторизованы!';
                    $mssg2 = '<a href="index.php">Перейти на главную</a>';
                ?>
                <p><?if(isset($mssg))echo $mssg;?></p>
                <p><?if(isset($mssg2))echo $mssg2;?></p>

            <?else:?>
                <div class="col-md-5 mt-5">
                    <div class="card">
                        <div class="card-header">
                            <h3>Log in</h3>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="login.php" accept-charset="UTF-8" enctype="multipart/form-data">
                                <div class="tile-body">
                                    <div class="form-group">
                                        <label class="control-label">YOUR EMAIL</label>
                                        <input name="email" class="form-control" type="email" required>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">YOUR PASSWORD</label>
                                        <input name="password" class="form-control" type="password" required>
                                    </div>
                                    <div class="tile-footer">
                                        <button class="btn btn-primary" type="submit" name="save">
                                            <i class="fa fa-fw fa-lg fa-check-circle"></i>Добавить
                                        </button>
                                    </div>
                            </form>
                        </div>
                    </div>
                </div>
            <?endif;?>
        </div>
    </div>

<?php
mysqli_close($link);
include_once('view/footer.php');
?>