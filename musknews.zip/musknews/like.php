<?php
include_once('config.php');

$link = mysqli_connect($host, $user, $password, $database)
or die("Ошибка " . mysqli_error($link));

/** Получаем наш ID статьи из запроса */
$id = intval($_POST['id']);
$usr = intval($_POST['usr']);
$count = 0;
$message = '';
$error = true;
/** Если нам передали ID то обновляем */
if($id){
    /** Обновляем количество лайков в статье */
    $query3 = $link->query("SELECT `id_article`, `id_user` FROM `likes` WHERE `id_article` = '$id' AND `id_user` = '$usr'");
    $row3 = $query3->fetch_assoc();

    if ($row3) {
        $query = $link->query("UPDATE `articles` SET `count_like` = `count_like`-1  WHERE `id` = '$id'");
        $query2 = $link->query("DELETE FROM `likes` WHERE `id_article` = '$id' AND `id_user` = '$usr'");
    }else {
        $query = $link->query("UPDATE `articles` SET `count_like` = `count_like`+1  WHERE `id` = '$id'");
        $query2 = $link->query("INSERT INTO `likes` VALUES (NULL, $id,$usr)");
    }


    /** Выбираем количество лайков в статье */
    $query = $link->query("SELECT count(`id`) FROM `likes` WHERE `id_article` = '$id'");
    $result = $query->fetch_assoc();
    $res = $result["count(`id`)"];
    $query6 = $link->query("UPDATE `articles` SET `count_like` = '$res' WHERE `id` = '$id';");
    $getMyLike = $link->query("SELECT count(`id`) as num FROM `likes` WHERE `id_article` = '$id' AND `id_user` = '$usr'");
    $getMyLike = $getMyLike->fetch_assoc();
    $getMyLike = $getMyLike['num'];
    ($getMyLike) ? $isActive = true : $isActive = false;
    $count = isset($result["count(`id`)"]) ? $result["count(`id`)"]  : 0;

    $error = false;
}else{
    /** Если ID пуст - возвращаем ошибку */

    $error = true;
    $message = 'Статья не найдена';
}


/** Возвращаем ответ скрипту */

// Формируем масив данных для отправки
$out = array(
    'error' => $error,
    'message' => $message,
    'count' => $count,
    'isActive' => $isActive
);

// Устанавливаем заголовот ответа в формате json
header('Content-Type: text/json; charset=utf-8');

// Кодируем данные в формат json и отправляем
echo json_encode($out);