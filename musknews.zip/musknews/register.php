<?php
require_once 'config.php';

$link = mysqli_connect($host, $user, $password, $database)
or die("Ошибка " . mysqli_error($link));

if (!empty($_POST['password']) && !empty($_POST['email']))
{
    $email = $_POST['email'];
    $pass = $_POST['password'];
    $link->query("INSERT INTO `users` (email, password) VALUES ('$email', '$pass')") or die($link->error);
    $_SESSION['msg'] = 'вы успешно зарегились';
    header("Location: index.php");
}


include_once('view/header.php');
?>
    <div class="flex-center position-ref full-height">
        <div class="container">
            <?if (isset($_SESSION['id'])):?>
                <div>
                    <p>Вы уже авторизованы!</p>
                    <p><a href="index.php">Перейти на главную</a></p>
                </div>
            <?else:?>
                <div class="col-md-5 mt-5">
                    <div class="card">
                        <div class="card-header">
                            <h3>Create account</h3>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="register.php" accept-charset="UTF-8" enctype="multipart/form-data">
                                <div class="tile-body">
                                    <div class="form-group">
                                        <label class="control-label">YOUR EMAIL</label>
                                        <input name="email" class="form-control" type="email" required>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">YOUR PASSWORD</label>
                                        <input name="password" class="form-control" type="password" required>
                                    </div>
                                    <div class="tile-footer">
                                        <button class="btn btn-primary" type="submit" name="save">
                                            <i class="fa fa-fw fa-lg fa-check-circle"></i>Добавить
                                        </button>
                                    </div>
                            </form>
                        </div>
                    </div>
                </div>
            <?endif;?>
        </div>
    </div>
<?php
mysqli_close($link);
include_once('view/footer.php');
?>