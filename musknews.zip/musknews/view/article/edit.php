<?php
include_once('../header.php');
$host = 'musknews'; // адрес сервера
$database = 'database'; // имя базы данных
$user = 'root'; // имя пользователя
$password = 'root'; // пароль
$link = mysqli_connect($host, $user, $password, $database);
$id = $_GET['id'];
$q ="SELECT * FROM `articles` WHERE `id` = $id";
$res = mysqli_query($link, $q) or die("Ошибка " . mysqli_error($link));
$row = $res->fetch_assoc();
?>
<div class="flex-center position-ref full-height">
    <div class="container">
        <div class="col-md-auto mt-5">
            <div class="card">
                <div class="card-header">
                    <h3>Update post</h3>
                </div>
                <div class="card-body">
                    <form method="POST" action="../../../articles.php?id=<?php echo $row['id'] ?>" accept-charset="UTF-8" enctype="multipart/form-data">
                        <div class="tile-body">
                            <div class="form-group">
                                <label class="control-label">Title</label>
                                <input name="name" class="form-control" type="text" required="" value="<?php echo $row['name'] ?>">
                            </div>
                            <div class="form-group">
                                <label class="control-label">Annotation</label>
                                <textarea name="annotation" class="form-control" rows="4"><?php echo $row['annotation'] ?></textarea>
                            </div>
                            <div class="form-group">
                                <label class="control-label">Content</label>
                                <textarea name="body" class="form-control" rows="4"><?php echo $row['body'] ?></textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <input name="image_up[]" type="file" class="form-control-file" id="image_up" required multiple>
                        </div>
                        <div class="tile-footer">
                            <button class="btn btn-primary" type="submit" name="update">
                                <i class="fa fa-fw fa-lg fa-check-circle"></i>Добавить
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include_once('../footer.php');
?>