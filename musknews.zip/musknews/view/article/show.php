<?php
require_once '../../config.php'; // подключаем скрипт
include_once('../header.php');
$link = mysqli_connect($host, $user, $password, $database)
or die("Ошибка " . mysqli_error($link));
$id = $_GET['id'];
$q ="SELECT * FROM `articles` WHERE `id` = $id";
$res = mysqli_query($link, $q) or die("Ошибка " . mysqli_error($link));
$row = $res->fetch_assoc();

$usr = $_SESSION['id'];
$getMyLike = $link->query("SELECT count(`id`) as num FROM `likes` WHERE `id_article` = '$id' AND `id_user` = '$usr'");
$getMyLike = $getMyLike->fetch_assoc();
$getMyLike = $getMyLike['num'];
($getMyLike) ? $isActive = true : $isActive = false;
mysqli_close($link);
?>
<div class="flex-center position-ref full-height">
    <div class="container bg">
        <div class="col-md-auto mt-5">
            <h1>Просмотр:</h1>
            <p><a href="../../index.php" class="btn btn-success">Статьи</a></p>
            <div class="col-md-12">
                <div class="card mt-5">
                    <div class="card-body">
                        <h2 class="card-title"><?php echo $row['name'];?></h2>
                        <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                            <div class="carousel-inner">
                                <? $files = array_values(array_diff(scandir("../../img/" . $row['id']), array('.','..'))); ?>
                                <div class="carousel-item active">
                                    <img class="d-block w-100" src="../../img/<? echo $row['id'] . '/' . $files[0]?>" alt="0 слайд">
                                </div>
                                <?php
                                for ($i = 1; $i < count($files); $i++): ?>
                                    <div class="carousel-item">
                                        <img class="d-block w-100" src="../../img/<? echo $row['id'] . '/' . $files[$i]?>" alt="Слайд <?$i?>">
                                    </div>
                                <?php endfor; ?>
                            </div>
                            <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>
                        <p class="card-text"><?php echo $row['body'];?></p>
                        <div class="like <?if($isActive) echo 'active'; ?>" data-id="<?=$id?>" data-usr="<?=$_SESSION['id']?>">
                            <span class="counter"><?=$row['count_like']?></span>
                        </div>
                        <p class="card-text"><?php echo $row['created_at'];?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    <script>
        $(document).ready(function() {
            $(".like").bind("click", function() {
                var link = $(this);
                var id = link.data('id');
                var usr = link.data('usr');
                console.log(link);
                $.ajax({
                    url: "../../../like.php",
                    type: "POST",
                    data: {id:id, usr:usr}, // Передаем ID нашей статьи
                    dataType: "json",
                    success: function(result) {
                        if (!result.error){ //если на сервере не произойло ошибки то обновляем количество лайков на странице
                            console.log(result);
                            link.addClass('active');
                            if(result.isActive){
                                link.addClass('active');
                            }else{
                                link.removeClass('active');
                            }
                            // помечаем лайк как "понравившийся"
                            $('.counter',link).html(result.count);

                        }else{
                            alert(result.message);
                        }
                    }
                });
            });
        });
    </script>
<?php
include_once('../footer.php');
?>