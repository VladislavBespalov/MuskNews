<?php
$host = 'musknews'; // адрес сервера
$database = 'database'; // имя базы данных
$user = 'root'; // имя пользователя
$password = 'root'; // пароль
session_start();


