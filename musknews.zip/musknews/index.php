<?php
//header('Location: http://musknews/index.php');

require_once 'config.php'; // подключаем скрипт
include_once('view/header.php');

$link = mysqli_connect($host, $user, $password, $database)
or die("Ошибка " . mysqli_error($link));

$q ="SELECT * FROM `articles` ORDER BY `id` DESC";

if($_GET['sorting'])
{
    if($_GET['sorting'] === 'asc')
    {
        if($_GET['type'] === 'date')
        {
            $q ="SELECT * FROM `articles` ORDER BY `id`";
        }
        if($_GET['type'] === 'like')
        {
            $q ="SELECT * FROM `articles` ORDER BY `count_like`";
        }
    }
    else {
        if($_GET['type'] === 'date')
        {
            $q ="SELECT * FROM `articles` ORDER BY `id` DESC";
        }
        if($_GET['type'] === 'like')
        {
            $q ="SELECT * FROM `articles` ORDER BY `count_like` DESC";
        }
    }
}
$result = mysqli_query($link, $q) or die("Ошибка " . mysqli_error($link));
?>
<div class="container">
    <div class="col-md-auto">
        <h1>Список статей</h1>
        <?if ($_SESSION['is_admin']):?>
            <p><a href="/view/article/create.php" class="btn btn-info">Создать</a></p>
        <?endif;?>
        <form action="index.php?sorting=<?php echo $_REQUEST['sorting'] ?>&type=<?php echo $_REQUEST['type'] ?>" class="form_sort">
            <select name="sorting">
                <option value="asc">По Возрастанию</option>
                <option value="desc">По убыванию</option>
            </select>
            <select name="type">
                <option value="date">Дате</option>
                <option value="like">Популярности</option>
            </select>
            <input type="submit" value="Сортировать по" class="btn btn-primary">
        </form>
        <div class="col-md-12">
            <?php while($row = $result->fetch_assoc()): ?>
            <div class="card mt-5">
                <div class="card-body">
                    <h2 class="card-title"><?php echo $row['name'];?></h2>
                    <? $files = array_values(array_diff(scandir("img/" . $row['id']), array('.','..'))); ?>
                    <img src="img/<?php echo $row['id'] . "/" . $files[0]?>"/>
                    <p class="card-text"><?php echo $row['annotation'];?></p>
                    <p class="card-text"><?php echo $row['created_at'];?></p>
                    <a href="view/article/show.php?id=<?php echo $row['id']?>" class="btn btn-info">Подробнее</a>

                    <?if ($_SESSION['is_admin']):?>
                        <a href="/view/article/edit.php?id=<?php echo $row['id']?>" class="btn btn-info">Edit</a>
                        <a href="articles.php?delete=<?php echo $row['id']?>" class="btn btn-danger">Удалить</a>
                    <?endif;?>
                    <?
                        $id = $row['id'];
                        $usr = $_SESSION['id'];
                        $getMyLike = $link->query("SELECT count(`id`) as num FROM `likes` WHERE `id_article` = '$id' AND `id_user` = '$usr'");
                        $getMyLike = $getMyLike->fetch_assoc();
                        $getMyLike = $getMyLike['num'];
                        ($getMyLike) ? $isActive = true : $isActive = false;
                    ?>
                    <div class="like <?if($isActive) echo 'active'; ?>" data-id="<?=$row['id']?>" data-usr="<?=$_SESSION['id']?>">
                        <span class="counter"><?=$row['count_like']?></span>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        $(".like").bind("click", function() {
            var link = $(this);
            var id = link.data('id');
            var usr = link.data('usr');
            console.log(link);
            $.ajax({
                url: "../../../like.php",
                type: "POST",
                data: {id:id, usr:usr}, // Передаем ID нашей статьи
                dataType: "json",
                success: function(result) {
                    if (!result.error){ //если на сервере не произойло ошибки то обновляем количество лайков на странице
                        console.log(result);
                        link.addClass('active');
                        if(result.isActive){
                            link.addClass('active');
                        }else{
                            link.removeClass('active');
                        }
                        // помечаем лайк как "понравившийся"
                        $('.counter',link).html(result.count);

                    }else{
                        alert(result.message);
                    }
                }
            });
        });
    });
</script>
<?php
include_once('view/footer.php');
?>
