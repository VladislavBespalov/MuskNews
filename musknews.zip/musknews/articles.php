<?php
require_once 'config.php';

$link = mysqli_connect($host, $user, $password, $database)
or die("Ошибка " . mysqli_error($link));

if (isset($_POST['save']))
{
    $name = $_POST['name'];
    $annotation = $_POST['annotation'];
    $body = $_POST['body'];
    $link->query("INSERT INTO `articles` (name, annotation, body) VALUES('$name', '$annotation', '$body')") or die($link->error);
    $q ="SELECT `id` FROM `articles` ORDER BY `id` DESC LIMIT 1";
    $res= mysqli_query($link, $q);
    $count = intval($res->fetch_assoc()["id"]);
    $dir = mkdir('img/' . $count);
    for ($i = 0; $i < count($_FILES['image']['name']); $i++)
    {
        $uploadfile = 'img/' . $count . '/' . $_FILES['image']['name'][$i];
        $file = move_uploaded_file($_FILES['image']['tmp_name'][$i], $uploadfile);
    }
    header("Location: http://musknews/");
}

if(isset($_POST['update']))
{
    $id = $_GET['id'];
    $name = $_POST['name'];
    $annotation = $_POST['annotation'];
    $body = $_POST['body'];
    $link->query("UPDATE `articles` SET `name` = '$name', `annotation` = '$annotation', `body` = '$body' WHERE `id` = $id") or die($link->error);
    delTree("img/" . $id);
    $dir = mkdir("img/" . $id);
    for ($i = 0; $i < count($_FILES['image_up']['name']); $i++)
    {
        $uploadfile = 'img/' . $id . '/' . $_FILES['image_up']['name'][$i];
        $file = move_uploaded_file($_FILES['image_up']['tmp_name'][$i], $uploadfile);
    }
    header("Location: http://musknews/");
}

function delTree($dir) {
    $files = array_diff(scandir($dir), array('.','..'));
    foreach ($files as $file) {
        (is_dir("$dir/$file")) ? delTree("$dir/$file") : unlink("$dir/$file");
    }
    return rmdir($dir);
}

if(isset($_GET['delete']))
{
    $id = $_GET['delete'];
    $link->query("DELETE FROM `articles` WHERE `id` = '$id'");
    delTree("img/" . $id);
    header("Location: http://musknews/");
}

mysqli_close($link);


